/*
f) Implementar la clase DemasiadoRapidoException. Implementar este diseño con la estructura más convincente.
 */
package POLIMORFISMO;
//Creamos una clase excepción
public class DemasiadoRapidoException extends Exception{
 public DemasiadoRapidoException(String msg){
     super(msg);
 }
    
}
